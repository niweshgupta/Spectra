package com.weather.user.atry;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class developer extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.developer);
        TextView textView=(TextView)findViewById(R.id.textView);
        TextView textView1=(TextView)findViewById(R.id.textView2);
        Button button2=(Button)findViewById(R.id.button46);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(Intent.ACTION_DIAL);
                String no="9830787618";
                in.setData(Uri.parse("tel:"+no));
                startActivity(in);

                Toast.makeText(developer.this,"Call",Toast.LENGTH_LONG).show();
            }
        });
    }
}
