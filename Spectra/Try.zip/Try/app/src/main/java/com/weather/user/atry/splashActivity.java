package com.weather.user.atry;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class splashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        Thread Timer=new Thread(){
            public void run()
            {
                try {
                    int Timer=0;
                    while (Timer<5000)
                    {
                        sleep(100);
                        Timer=Timer+100;
                    }
                    Intent intent1=new Intent(splashActivity.this,DashboardActivity.class);
                    startActivity(intent1);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                finally {
                    finish();
                }
            }
        };
        Timer.start();
    }
}
