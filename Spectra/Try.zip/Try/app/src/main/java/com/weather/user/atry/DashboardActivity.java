package com.weather.user.atry;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class DashboardActivity extends AppCompatActivity {

    CardView map1;
    CardView weather1;
    CardView sos1;
    CardView Tool1;
    ImageView Infor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        map1 = (CardView)findViewById(R.id.Hydral);
        weather1 = (CardView)findViewById(R.id.Weather);
        sos1 = (CardView)findViewById(R.id.SOS);
        Tool1 = (CardView)findViewById(R.id.Ingento);
        Infor = (ImageView)findViewById(R.id.information);

        map1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Hydral Report With Map",Toast.LENGTH_LONG).show();
                Intent intent1 = new Intent(DashboardActivity.this, MapsActivity.class);
                startActivity(intent1);
            }
        });
        weather1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Weather Report",Toast.LENGTH_LONG).show();
                Intent intent2 = new Intent(DashboardActivity.this, MainActivity.class);
                startActivity(intent2);
            }
        });
        sos1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"SOS Call To Authority",Toast.LENGTH_LONG).show();
                Intent intent3 = new Intent(DashboardActivity.this, developer.class);
                startActivity(intent3);
            }
        });
        Tool1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Web Tool Ingento Solutions",Toast.LENGTH_LONG).show();
                Intent intent4 = new Intent(DashboardActivity.this, webviewActivity.class);
                startActivity(intent4);
            }
        });
        Infor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"editor.ingentosolutions@gmail.com",Toast.LENGTH_LONG).show();
                Toast.makeText(getApplicationContext(),"7003084315 / 9874371246",Toast.LENGTH_LONG).show();
            }
        });

    }
}
