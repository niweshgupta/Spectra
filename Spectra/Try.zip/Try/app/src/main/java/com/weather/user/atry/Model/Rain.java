package com.weather.user.atry.Model;

public class Rain {
    private double __invalid_name__3h;

    public Rain() {
    }

    public double get__invalid_name__3h() {
        return __invalid_name__3h;
    }

    public void set__invalid_name__3h(double __invalid_name__3h) {
        this.__invalid_name__3h = __invalid_name__3h;
    }
}
